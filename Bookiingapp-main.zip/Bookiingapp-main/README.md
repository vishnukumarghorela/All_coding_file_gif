//create a model for the booking  =  which have fields like data , time and service type
//create a model staff model = name , email , role
//create a model for the service  = name , duration , price ;
//create a model for user name , email ,password