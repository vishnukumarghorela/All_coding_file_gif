
import { Counter } from "./Counter/Counter";


function App(){
  return(<>
  <Counter/>
  </>)
}
export default App;
